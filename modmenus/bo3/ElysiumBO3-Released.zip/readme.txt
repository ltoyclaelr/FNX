

folder 'ElysiumBO3' and sprx file goes in hdd/tmp/
eboot goes in your game folder